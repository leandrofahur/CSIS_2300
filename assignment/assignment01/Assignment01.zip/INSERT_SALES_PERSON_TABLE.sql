INSERT INTO SALES_PERSON
(`Salesperson_number`, `Slastname`, `Sfirstname`, `HireDate`, `WageRate`, `ComRate`, `SPhone`, `SEmailaddress`)
VALUES(1, 'Machado', 'Guilherme', '2021-10-10', 0, 0, 0, 'guilherme.machado@mail.com');
