SELECT `CustomerID`, `LastName`, `FirstName`
FROM CUSTOMER WHERE `CustomerID` = 2;