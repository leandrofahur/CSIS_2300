SELECT `CustomerID`, `LastName`, `FirstName`
FROM CUSTOMER;
