INSERT INTO CUSTOMER
(`CustomerID`, `LastName`, `FirstName`, `Address`, `Phone`, `City`, `State`, ZIP, `EmailAddress`, `TYPE`)
VALUES(1, 'Machado', 'Leandro', '.', 0, '.', '.', '.', 'leandromachado@mail.com', 0);
