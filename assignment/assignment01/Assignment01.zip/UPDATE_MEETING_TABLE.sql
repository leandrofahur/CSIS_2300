UPDATE MEETING
SET `MeetingID`=1, `CustomerID`=1, `Salesperson_number`=1, `Remarks`='He is more than awesome!!!';
