INSERT INTO MEETING
(`MeetingID`, `CustomerID`, `Salesperson_number`, `Remarks`)
VALUES(1, 1, 1, 'My son is awesome!!!');