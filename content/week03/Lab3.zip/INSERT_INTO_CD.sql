INSERT INTO CD (`cID`, `Title`, `Price`)
VALUES(1, 'Mix', 19);

INSERT INTO CD (`cID`, `Title`, `Price`)
VALUES(2, 'Compilation', 11);


