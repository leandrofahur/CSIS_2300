CREATE TABLE DEPARTMENT(
	DepartmentName 		Char(35) 	PRIMARY KEY,
	BudgetCode			Char(30)	NOT NULL,
	OfficeNumeber		Char(15)	NOT NULL,
	DepartmentPhone		Char(12)	NOT NULL
);
