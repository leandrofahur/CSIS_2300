INSERT INTO TRACK (`cID`, `Num`, `Title`, `TimeCol`, `aID`)
VALUES(1, 1, 'Reason', 239, 1);

INSERT INTO TRACK (`cID`, `Num`, `Title`, `TimeCol`, `aID`)
VALUES(1, 2, 'I Love you', 239, 0);

INSERT INTO TRACK (`cID`, `Num`, `Title`, `TimeCol`, `aID`)
VALUES(1, 3, 'Breathless', 239, 0);

INSERT INTO TRACK (`cID`, `Num`, `Title`, `TimeCol`, `aID`)
VALUES(1, 4, 'I am no 4', 239, 0);

INSERT INTO TRACK (`cID`, `Num`, `Title`, `TimeCol`, `aID`)
VALUES(2, 1, 'Lion', 239, 0);

INSERT INTO TRACK (`cID`, `Num`, `Title`, `TimeCol`, `aID`)
VALUES(2, 2, 'Catman', 239, 0);
