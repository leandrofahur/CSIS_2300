INSERT INTO ARTIST (`aID`, `Name`)
VALUES(1, 'Jango');

INSERT INTO ARTIST (`aID`, `Name`)
VALUES(2, 'Ranna');

